﻿@{
	AllNodes = @(
		@{
			NodeName = '*'            PsDscAllowPlainTextPassword = $true
            downloadfolderpath = "C:\temp\DSCDownload"            
		}
        @{
			NodeName = "WebServerConfig"            LogDirectory = "C:\inetpub\logs\LogFiles"
            TraceLogDirectory = "C:\inetpub\logs\FailedReqLogFiles"
            DefaultApplicationPoolName = "DefaultAppPool"
		}
	)
}