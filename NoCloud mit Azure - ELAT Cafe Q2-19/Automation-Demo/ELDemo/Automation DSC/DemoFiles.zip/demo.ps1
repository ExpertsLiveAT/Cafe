﻿Configuration demo
{
    Import-DscResource -ModuleName @{ModuleName = 'xWebAdministration';ModuleVersion = '2.5.0.0'}
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'



    node WebServerConfig
    {
        #create the default download folder
        File Create_DownloadFolder
        {
            Type='Directory'
            DestinationPath = $node.downloadfolderpath
            Ensure = 'Present'
        }

        Script Download_NodeJS
        {
            DependsOn = "[File]Create_DownloadFolder"
            GetScript = 
            {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = ('True' -in (Test-Path "C:\temp\dscdownload\nodejs.msi"))
                }
            }

            SetScript = 
            {
                Invoke-WebRequest -Uri 'https://nodejs.org/dist/v8.11.2/node-v8.11.2-x64.msi' -OutFile 'C:\temp\dscdownload\nodejs.msi'
            }

            TestScript = 
            {
                $Status = ('True' -in (Test-Path "C:\temp\dscdownload\nodejs.msi"))
                $Status -eq $True
            }

        }

        WindowsFeature WebServer
        {
            Ensure  = 'Present'
            Name    = 'Web-Server'
        }

        WindowsFeature InstallDotNet
        {
            Ensure  = 'Present'
            Name    = 'Web-Asp-Net45'
            DependsOn = '[WindowsFeature]WebServer'
        }

        # IIS Site Default Values
        xWebSiteDefaults SiteDefaults
        {
            ApplyTo                 = 'Machine'
            LogFormat               = 'IIS'
            LogDirectory            = $node.LogDirectory
            TraceLogDirectory       = $node.TraceLogDirectory
            DefaultApplicationPool  = $node.DefaultApplicationPool
            AllowSubDirConfig       = 'true'
            DependsOn               = '[WindowsFeature]WebServer'
        }

        # IIS App Pool Default Values
        xWebAppPoolDefaults PoolDefaults
        {
            ApplyTo               = 'Machine'
            ManagedRuntimeVersion = 'v4.0'
            IdentityType          = 'ApplicationPoolIdentity'
            DependsOn             = '[WindowsFeature]WebServer'
        }

        Script DisableFirewall 
        {
            GetScript = {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                    Result = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
                }
            }

            SetScript = {
                Set-NetFirewallProfile -All -Enabled False -Verbose
            }

            TestScript = {
                $Status = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
                $Status -eq $True
            }
        }
    }    
}